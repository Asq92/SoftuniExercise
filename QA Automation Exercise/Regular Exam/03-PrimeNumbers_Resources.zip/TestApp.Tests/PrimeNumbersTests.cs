﻿using NUnit.Framework;

namespace TestApp.Tests
{
    public class PrimeNumbersTests
    {
        [Test]
        public void StartGreaterThanEnd_ShouldReturnErrorMessage()
        {
            
        }

        [Test]
        public void OneToOne_NoPrimes_ReturnsEmptyString()
        {
            
        }

        [Test]
        public void ZeroToOne_NoPrimes_ReturnsEmptyString()
        {
            
        }

        [Test]
        public void TwoToThree_ReturnsTwoThree()
        {
            
        }

        [Test]
        public void OneToFifty_ReturnsAllPrimesCorrectly()
        {
            
        }
    }
}
